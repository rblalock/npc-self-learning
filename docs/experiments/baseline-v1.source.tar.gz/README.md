# Tactical Air

Prototype 0.2: a portable Rust library for enemies that learn which **authored, legal tactics** work, plus a playable browser arena that makes the learning visible.

The game owns perception, movement, combat and rewards. The library owns bounded preference updates, deterministic choice, and memory. It never changes health, damage, movement speed, cooldowns or available abilities.

## Run the prototype

Prerequisites: Rust with Cargo, Node.js 22.12+ (24 recommended), and npm. Install the Wasm target and matching binding generator once:

```sh
rustup target add wasm32-unknown-unknown
cargo install wasm-bindgen-cli --version 0.2.129 --locked
npm ci
npm run dev
```

Open **http://localhost:5173**. The build generates real Rust WebAssembly; there is no JavaScript replacement policy. `npm run dev:ui` skips rebuilding unchanged Rust. `npm run build` creates a static application in `apps/arena/dist`, with relative asset paths.

- **Missions:** the game opens at a two-wave mission. Survive contact, decide whether to intercept the scout, then face reinforcements using its delivered evidence. Win to start the next mission; lose to retry from wave one. Enemy memory carries through both transitions. Mission memory lasts in this tab until reload or switching to Experiments.
- **Play yourself / Watch demo:** top controls switch between manual play and the demo. WASD/arrows move, mouse aims, hold click fires, Space dashes, P pauses. The demo movement selector explicitly offers Circle clockwise, Circle counterclockwise, and Use cover + dodge. These control the demo player, not enemy tactics.
- **Intelligence notes:** Memory shows tactic odds and observations; Last round shows actual learning changes with expandable evidence. The survival graph stays visible in both views.
- **Experiments → Change your movement:** repeat your own movement for four rounds, inspect the evidence, then try a different route, direction, or cover for three rounds. Demo mode explicitly changes its circling direction; manual keys never reverse. Uses fresh memory and preserves free-play saves.
- **Experiments → Compare enemy learning:** two three-round manual sets, randomized conditions, notes and local JSON export. Intel is revealed after both sets.
- **Experiments → Require scout reports:** intercept the violet scout before it reaches the relay to stop new information reaching the next squad.
- **Experiments → Random tactics (no learning):** enemies sample their legal tactics uniformly. Stored preferences remain intact and these rounds do not train.
- **New round:** discards unfinished evidence. Completed practice rounds save policy memory locally in the browser, independently of missions.
- **Experiments → Reset memory:** starts a new independent memory with equally likely tactics.

Switching between Missions and Experiments preserves your control mode. Experiments opens paused so you can choose a test or start free practice. Held movement and fire inputs clear when a round ends, a new round starts, the control mode changes, play pauses, or focus leaves the arena.

The manual game currently needs a keyboard and pointer. Touch and narrow-screen visits open in Watch demo, with a visible keyboard-and-mouse requirement for manual play.

## Repository boundaries

```text
crates/tactical-air-core    Pure Rust policy, validation, deterministic RNG, snapshots
crates/tactical-air-wasm    Small wasm-bindgen wrapper over that same core
crates/tactical-air-ffi     Native shared/static library, opaque C ABI and C header
apps/arena                 TypeScript combat simulation, study flow, Canvas renderer, UI
packages/browser           Small typed client over the same Wasm API
scripts                    Wasm build, real-arena evaluation and native C smoke test
```

The core accepts arbitrary host-defined roles, contexts and actions. The arena happens to use three roles with two tactics each: vanguard (close distance / hold lane), flanker (left / right), and ranger (aim / lead movement). The arena uses one context initially to keep its behavior inspectable; the library supports multiple contexts.

At an encounter boundary:

1. The host supplies a role, context and legal action mask.
2. The library samples a tactic and returns a decision ID.
3. The game executes that tactic using its ordinary combat rules.
4. The host reports observed reward against the decision ID.
5. A commit aggregates evidence, applies bounded updates, and enables a versioned save.

Selection is a contextual bandit with exploration, not a neural network or an LLM. It learns rewards supplied by the host; it does not independently know what is fun or fair. The host must enforce truthful observations and useful attribution. The browser enemy host tracks last-seen positions and uses line of sight; the core itself cannot verify world geometry.

See [learning rules and limitations](docs/learning.md), [JSON contract](docs/contract.md), and [Rust, browser, C#, and C++ integration](docs/integration.md).

## Use it in another game

Rust games can depend on `tactical-air-core` directly. Browser games use the Wasm wrapper. Native engines can link `tactical-air-ffi` through its C ABI; `docs/integration.md` supplies C# and C++ starting points.

The C ABI is a tested foundation for Unity and Unreal adapters. This repository does **not** yet contain tested Unity packages or Unreal plugins. JSON calls are intended for tactical decisions and encounter commits, not every render frame. Each mutable engine has one owner; parallel game systems need independent instances or host-side synchronization.

## Verification

```sh
npm test                     # Rust tests, Wasm build, actual arena/Wasm integration
npm run test:ffi              # Real C caller linked against native library (macOS/Linux)
npm run build                 # TypeScript check and browser production build
npm run evaluate:arena        # Multi-seed scripted combat evaluation; JSON output
npm run evaluate:reversal     # Inspect learned tactic reversal across three seeds
npm run evaluate:held-out     # Freeze learned policies; compare on other controllers
npm run evaluate:adaptation   # Build Wasm; compare online/frozen/fixed/random after switches
cargo run -p tactical-air-core --example learning_benchmark --release
```

Core tests check reward-driven preference, reversed reward mappings, delayed recovery after counterplay, legal masks, unobserved and baseline evidence, bounded updates, snapshot validation and deterministic replay. Arena tests exercise actual combat outcomes through the compiled Wasm module. Native tests exercise the exported ABI and allocation ownership.

The synthetic core benchmark is deliberately separate from game evaluation. It demonstrates learning under controlled rewards, including a period of worse performance after the opponent changes strategy. It does not prove improvement in this arena or that humans find the mechanic fun.

The [current held-fixed evaluation](docs/held-out-evaluation.md) separates training from measurement. The [original arena evaluation](docs/arena-evaluation.md) is retained as a historical 0.1 result. See the [0.2 prototype guide](docs/counterplay-prototype.md) and [current verification record](docs/verification-0.2.md).

The [adaptation comparison](docs/experiments/adaptation-v1.md) completed 8,568 encounters under a [versioned protocol](docs/experiments/adaptation-v1.protocol.json): 32 policy seeds, all eight fixed tactic combinations considered, and identical trained memories branched into continued versus frozen learning. Continued learning helped after direction reversal, hurt against feints, and made no damage difference against cover; the selected fixed policy still won the primary reversal comparison. The runner retains every round and refuses to overwrite evidence; use `-- --out docs/experiments/adaptation-v1-replication` for a fresh output prefix. Progress toward a public demo and reusable release is tracked in the [roadmap](docs/roadmap.md) and [research status](docs/research-status.md).

After a run, `node scripts/verify-adaptation.mjs docs/experiments/adaptation-v1.results.json` checks source identities, all candidate/seed/round records, frozen memory, summary arithmetic and the primary bootstrap calculation. Pass a replication's results path to verify that run instead.

The isolated reward-attribution experiment keeps the original simulator, core and v1 evidence unchanged. Its [protocol](docs/experiments/reward-attribution-v1.protocol.json) defines a single 50/50 individual/team-average damage reward and advancement criteria before measurement. Run its additional tests with `node --test scripts/reward.test.mjs`. After the existing Wasm and simulator build steps, reproduce it with `node scripts/evaluate-rewards.mjs --out docs/experiments/reward-attribution-v1-replication`; verify with `node scripts/verify-rewards.mjs docs/experiments/reward-attribution-v1-replication.results.json`. The runner checks original source identities and exactly replays one complete reference seed before reusing the original comparisons. The verifier independently replays every candidate choice, reward and commit through Wasm.

## What we are testing next

The player-facing target is: **“They figured out what I was doing—and I figured out how to use that against them.”**

The guided loop, factual recaps, scout-delivered memory, blind comparison and typed Wasm client are implemented. Use [the playtest protocol](docs/playtest.md) to determine whether people can notice and exploit the learning.

The first mission loop is implemented: two waves, scout-delivered learning, win/retry screens, and memory retained across deployments. It repeats the same battlefield and enemy roster; mission numbers do not add stat multipliers. Learning can make familiar habits more dangerous, but every later mission is not guaranteed to be harder.

The first [reward-attribution comparison](docs/experiments/reward-attribution-v1.md) rejected the tested 50/50 team blend: it reduced damage after both reversal and feints, so it remains experimental. Next, test contribution credit that preserves useful individual reward differences; see the [interpretation](docs/experiments/reward-attribution-v1-interpretation.md). Then evaluate new scenarios and extend the human comparison to the fixed baseline, measuring noticed adaptation, deliberate counterplay, fairness and enjoyment. The built-in blind comparison currently supports adaptive versus random choices only; it is not yet the fixed-policy human study. Unity, Godot and other game-engine integrations remain deferred.

## Relationship to Ink and visual references

This is inspired by the separation of learned choices and fixed constraints discussed in [Ink's adaptive learning](https://github.com/siliconjungle/ink-lang/blob/main/docs/adaptive-learning.md) and [policy learning](https://github.com/siliconjungle/ink-lang/blob/main/docs/policy-learning.md). It is an independent Rust implementation, **not an Ink runtime, compiler integration, or formal proof system**.

The illustrated field map uses an original AI-generated watercolor terrain plate with authored Canvas fortifications and unit counters. [Asset provenance](docs/assets/README.md) records the prompt and font licenses. The first geometric arena built on our original diagram. [Factory](https://github.com/Khalidabdi1/factory) informed the fine-line technical presentation; [Hollowflux](https://developers.openai.com/showcase/hollowflux) informed the emphasis on readable combat. No assets or game source were copied from either project.
