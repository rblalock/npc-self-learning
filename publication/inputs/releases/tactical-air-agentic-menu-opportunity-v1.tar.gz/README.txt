Tactical Air: seven-plan opportunity diagnostic

Node.js 24; no packages or model account required.
shasum -a 256 -c SHA256SUMS
npm run verify

The verifier reruns all 2,236 charged probes and trajectory fights and compares
the complete record. Prior v2 calibration and warmups are reused, not rerun.
The input, frozen sources, generated simulation and Wasm are included.
Greedy uses hidden current scenarios and seven counterfactual simulations per
fight. Its improvement is a privileged diagnostic, not an agent result or a
bound on the globally optimal policy. Familiar-world development scope only.
