Tactical Air: seven-plan opportunity diagnostic

Exact frozen replay currently requires Node.js 24.22.0 on macOS arm64 and
system tar. The verifier includes runtime metadata in its equality checks.
Other platforms/Node patches are not accepted by this frozen verifier.
No npm packages or model account required.
shasum -a 256 -c SHA256SUMS
npm run verify

The verifier reruns all 2,236 charged probes and trajectory fights and compares
the complete record. Prior v2 calibration and warmups are reused, not rerun.
The input, frozen sources, generated simulation and Wasm are included.
Greedy uses hidden current scenarios and seven counterfactual simulations per
fight. Its improvement is a privileged diagnostic, not an agent result or a
bound on the globally optimal policy. Familiar-world development scope only.
