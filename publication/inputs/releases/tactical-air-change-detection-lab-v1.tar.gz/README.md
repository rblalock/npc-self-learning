# Tactical Air: knowing when to forget

MIT-licensed Node.js 24 research kit. No npm install, API key or Rust rebuild.

Read [the guide](docs/change-detection-lab-v1.md) and [verification](docs/verification-change-detection-v1.md). Open docs/experiments/change-detection-v1-view.html for offline playback.

Run `shasum -a 256 -c SHA256SUMS`, `npm test`, `npm run verify:change`, and `npm run verify:development`. Reproduce to a new prefix as explained in the guide. Writers refuse overwrites.

All 69,120 reserved physical fights and 14,432 cached development transitions are retained. Neither automatic-forgetting rule passes. The existing learner remains unchanged. Cached development uses earlier physical tables and adds no new scored fights. The development verifier includes all its required tables; regenerating their original selection requires the separate opportunity-v2 audit.
