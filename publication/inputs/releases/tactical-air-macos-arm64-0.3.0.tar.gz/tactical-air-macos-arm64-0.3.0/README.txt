Tactical Air 0.3.0
Experimental C ABI binary for macOS arm64 only.
Compile your host against tactical_air.h; link -ltactical_air_ffi.
Set your runtime library search path to the library directory.
Source and other platform build instructions are in the source bundle.
No Unity, Godot, or Unreal plugin is included.
