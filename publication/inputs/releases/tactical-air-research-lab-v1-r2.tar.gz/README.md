# Tactical Air research lab

MIT-licensed, dependency-free headless research kit. Requires Node.js 24; no npm install, API key or Rust rebuild.

Read [the guide](docs/research-program.md) and [verification record](docs/verification-research-program-v1.md). Open docs/experiments/research-program-v1-view-2.html for the offline fieldbook.

Check files with `shasum -a 256 -c SHA256SUMS`, then `npm test`. Run `npm run verify:research` for all 72,000 main encounters. The guide explains fresh-output replication and the 3,584-encounter opportunity audit.

Six controlled screens and one post-hoc audit are preserved, including unfavorable outcomes. None of the five improvement proposals passed; the scripted harm-margin pass does not establish deception resistance. The original learner remains the reference.
