Tactical Air: incomplete between-round NPC review attempt

This is a stopped attempt, not a completed effectiveness comparison.
The permanent failure stop is retained. Do not reset or resume this journal.
Known costs and unknown timed-out costs must remain distinct.

Requires Node.js 24 and tar. No dependencies or model credentials.
Check contents: shasum -a 256 -c SHA256SUMS
Replay every recorded physical fight and decision: npm run verify

The kit preserves the actual study sources and recorded model outputs.
The partial verifier was added after the run; its checksum is included.
Replay makes no model calls and does not regenerate stochastic decisions.
Two familiar worlds do not establish unseen-world generalization.
