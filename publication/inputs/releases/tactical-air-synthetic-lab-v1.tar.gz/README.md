# Tactical Air synthetic lab v1

MIT-licensed headless research kit. Requires Node.js 24; no npm install, API key or Rust rebuild. The included immutable baseline archive supplies the actual combat and Rust/Wasm learner.

Read [the lab guide](docs/synthetic-lab.md). Open `docs/experiments/synthetic-population-v1-view.html` for the recorded comparison.

```sh
npm run test:synthetic
npm run verify:synthetic -- --full
npm run verify:feints
npm run evaluate:synthetic -- --out target/my-replication
npm run replay:synthetic -- --out target/my-replay
```

Results include unfavorable outcomes and source hashes. New runs refuse to overwrite old evidence. This package does not install a game-engine adapter or claim human-play effectiveness. The shipped game policy remains unchanged.
