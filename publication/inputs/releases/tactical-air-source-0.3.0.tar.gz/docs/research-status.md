# Research status

This is the evidence record for the prototype and the future microsite. Distinguish implementation checks, scripted effectiveness measurements, and human experience. Passing a correctness test is not an enjoyment result.

## Completed experiments

The [adaptation-v1 report](experiments/adaptation-v1.md) is complete and passed integrity checks: 8,568 actual encounters, 32 independent tactic-sampling seeds, one deterministic map, and three scripted movement changes. The [protocol](experiments/adaptation-v1.protocol.json) was specified before this run; the fixtures were already familiar. It is a local engineering experiment, not a public preregistration.

After clockwise training, continued learning gained **18.70 HP of damage per round [16.31, 21.09]** over the identical frozen learner against counterclockwise movement, in post-switch rounds 17–24. This meets the declared primary screening criterion. It still trailed the selected fixed policy by **12.14 HP [10.03, 14.53]**. Against direction feints, continued learning reduced damage by **4.73 HP [3.89, 5.58]** versus frozen memory. Cover produced exactly 72 HP under every tested policy. Brackets are paired seed-bootstrap 95% intervals; secondary comparisons are exploratory and unadjusted.

These results establish useful adaptation in one fixture, a regression in another, and an insensitive damage measure in the cover fixture. Moving tactic probabilities alone is not evidence of improvement. This original run established no human enjoyment, new-map generalization, scout-delivery benefit, or broad superiority over fixed policies. The later three-scenario screen below extends its scope without establishing arbitrary-world generalization.

The first serial execution was interrupted for runtime reasons after six of 32 seeds completed; no full result or statistical conclusion was produced. The same protocol then completed from the beginning with four independent workers. A test compares serial and worker execution of the same trial exactly. The learning algorithm, observations, controllers, sample count and decision threshold were not changed in response to outcomes.

The subsequent [reward-attribution experiment](experiments/reward-attribution-v1.md) tested a single 50/50 individual/team-average damage reward under a separate protocol. It completed 5,376 candidate encounters plus a 264-encounter exact reference replay, reusing verified original comparisons. **Do not promote:** only two of five predeclared gates passed. Candidate-minus-original late damage was −4.55 HP [−5.91, −3.28] after reversal and −0.66 HP [−1.08, −0.28] against feints. The candidate's continued-minus-frozen learning effect on feints was −4.22 HP [−4.88, −3.56]. Cover was unchanged. All candidate choices/feedback/commits were independently replayed through Wasm. The browser retains the original reward.

## Additive credit and fresh scenarios

The [additive-credit-v1 experiment](experiments/additive-credit-v1.md) preserves full personal damage credit and adds a teammate-only bonus. It completed 5,376 candidate encounters and a 264-encounter exact reference replay. **Do not promote:** three of five gates passed. Relative to original online learning, late damage gained only +0.42 HP [0.14, 0.75] on feints, below the 3 HP practical threshold, and +0.89 HP [0.28, 1.73] on reversal. Its continued-versus-frozen effect remained negative on feints: −4.78 HP [−5.63, −3.94]. Reversal retained +19.22 HP [17.02, 21.56]. Cover was unchanged.

The separately specified [scenario-transfer-v1 screen](experiments/scenario-transfer-v1.md) executed 11,760 actual encounters across three authored cover/spawn layouts and 16 fresh policy seeds. Both rules were evaluated regardless of development outcome. Aggregate original learning benefit was +9.13 HP [7.81, 10.63] on reversal and +3.44 HP [2.94, 4.03] on feints. Additive-minus-original was +1.28 HP [0.72, 1.94] on reversal and +0.03 HP [−0.13, 0.19] on feints. The candidate failed its feint-improvement gate and remains out of the game.

These results show environment dependence: feints hurt continued learning on the original map but helped on the three new layouts, by differing amounts. The aggregate averages each seed across the same three worlds, then bootstraps the 16 seed means. It does not treat 48 world/seed pairs as 48 independent maps. The new fixed policy was selected only on clockwise calibration and is not an oracle for reverse/feint behavior. None of these tests estimates human enjoyment.

All candidate policy decisions were independently replayed through Wasm. The scenario verifier also re-executed all fixed calibration/comparison encounters and one full seed for each reward rule in each world, matching exactly (960 combat replays). Original evidence remains reproducible from the immutable v1 source archive. Across the four scored experiments there are 31,080 encounter executions, excluding reference replays and verification replays; reused original baselines are not counted again.

## Evidence we can use

| Claim | Status and scope | Evidence |
| --- | --- | --- |
| Authored tactics can be selected using bounded learned preferences | Implemented and tested in Rust, Wasm and this arena | [Learning rules](learning.md), core/arena tests |
| Learning can improve enemy effectiveness over random selection | Supported in three of four tested scripted controllers; five seeds, one map | [Earlier held-fixed evaluation](held-out-evaluation.md) |
| Continued learning helps after a player strategy change | Supported for direction reversal; harmful for feints; no damage difference for cover | [Adaptation v1](experiments/adaptation-v1.md) |
| Learning beats a strong fixed strategy | Not supported on the primary reversal fixture: online 71.86 HP versus selected-fixed 84 HP; small exploratory advantage on feints | Same report |
| Blending individual and team rewards fixes the feint weakness | Not supported for the tested 50/50 blend; damage decreased on feints and reversal | [Reward attribution v1](experiments/reward-attribution-v1.md) |
| Blocking reports prevents new learning | Implemented and tested; old memory can still fade | [Prototype mechanics](counterplay-prototype.md), scout tests |
| Human players notice and enjoy adaptation | Unmeasured; longer fixed-baseline study implemented and QA-verified | [Human playtest plan](playtest.md) |
| The library works outside the arena | Independent Rust/browser guard hosts and release packages exist; third-party games and engine adapters remain untested | [Integration boundaries](integration.md) |

## What the game currently learns

It updates preferences among six authored tactics in one shared arena context. It does not invent maneuvers, model an individual player's route history, rewrite combat code, or increase stats. It optimizes authored rewards based largely on damage and survival of the acting enemy; those rewards are not a measure of fun.

## Interpretation and next investigation

The [post-hoc diagnostic](experiments/adaptation-v1-interpretation.md) identifies a reward-attribution problem worth testing: against feints, the flanker receives the same reward for either direction, although its direction changes damage dealt by the vanguard. Continued learning loses a useful left-flank preference. Ranger and vanguard preferences also change, so this does not isolate the complete cause of the regression.

The first reward comparison is now complete and unfavorable. Its [post-hoc interpretation](experiments/reward-attribution-v1-interpretation.md) identifies a concrete tradeoff: the blend adds a weak team contribution signal while reducing the existing reward difference between useful and ineffective individual tactics. The final left-flank preference rises slightly relative to the original, while rush and lead probabilities fall. This is consistent with the weaker damage result but is not a complete causal decomposition.

The additive follow-up is now complete. Preserving personal credit avoided the earlier blend's reversal regression but did not repair the original feint failure. The small observed gain does not meet the predeclared practical improvement threshold. Reward weighting alone has not solved the interaction in these tests. Investigate joint-role effects or retention under a new protocol instead of declaring the bonus successful.

The human study is ready to collect real participant evidence. Two automated production-browser sessions exercise both orders and 52 encounters; their responses are labeled synthetic and excluded from human analysis. Human sample size remains zero. See [the protocol](playtest.md) and [release quick start](releases/quickstart.md).

## Rules for subsequent iterations

1. Preserve protocols, unfavorable outcomes, incomplete human sessions and exclusion reasons.
2. Select comparison policies and thresholds before reading the new test results. Disclose familiar fixtures and exploratory analysis.
3. Change one substantive mechanism at a time and assign a new protocol/implementation identity. Verify the same source and binary artifacts used for measurement.
4. Report uncertainty at the independent unit: policy seed for this simulator, participant for human sessions, and scenario/map where varied. Repeated frames and rounds do not create independent people or worlds.
5. Show representative demos with aggregate results nearby. Never select a spectacular run and describe it as typical without checking.
6. Keep measurable enemy effectiveness, fairness, comprehension and enjoyment as distinct outcomes.

The emphasis on uncertainty rather than isolated point estimates is consistent with [Agarwal et al., *Deep Reinforcement Learning at the Edge of the Statistical Precipice*](https://arxiv.org/abs/2108.13264). This prototype is a small bandit in one arena; it does not reproduce that paper's broad multi-task benchmark or claim that bootstrap intervals remove its sampling limitations.

See the [roadmap](roadmap.md) for the sequence from measurement to human playtests, reusable releases and a public microsite.
