# Tactical Air roadmap

The product has three responsibilities: make adaptive enemies fun to play against, demonstrate exactly what the learner changes, and let other developers use the same library. Evidence of one does not substitute for the others.

## Delivered in 0.3.0

- Preserved the original experiments in a checksum-verified source/binary archive.
- Completed the additive teammate-credit experiment: 5,376 candidate encounters plus a 264-encounter reference replay. Rejected by the predeclared gates; the original reward remains in the game.
- Completed fresh-scenario validation: 11,760 encounters, three authored cover/spawn layouts, 16 fresh policy seeds, original/additive rewards, exact online/frozen branches, and a fixed policy selected only on clockwise calibration. Additive credit again failed its improvement gate.
- Independently replayed candidate choices/feedback/commits and complete combat checks. Negative results remain first-class evidence.
- Implemented the longer concealed fixed-versus-learning human playtest, structured questions, interruption/recovery/export, build fingerprints and automated-QA exclusions. Verified both condition orders in the production browser build.
- Prepared reusable Rust/Wasm/browser/native packages, separate guard examples, API/snapshot/support documentation, checksums and reproducible timing measurements.
- Built the public-facing microsite with the playable game, interactive evidence, explicit limitations, source and library downloads. Deployment identity and status are recorded separately so a prepared page is not mistaken for a verified publish.

## Next: collect real human evidence

Run the [human-fixed-v1 protocol](playtest.md) with 6–10 formative participants. Keep incomplete sessions and reports of confusion. Analyze unaided explanations, deliberate counterplay, fairness, enjoyment and frustration alongside combat outcomes. No human finding is established by automated QA. Recruiting or contacting participants is not automated by this repository.

Exit: a documented decision about whether players can recognize and enjoy the mechanic, with specific examples and failures. If the signal is unclear, revise telegraphs, tactical differences or the study length under a new version before adding scope.

## Next mechanism investigation

Both reward edits failed to solve the original feint regression. The additive rule preserved useful personal credit but added only +0.42 HP versus original on that fixture, while continued learning still lost 4.78 HP versus its frozen checkpoint. New-world feint differences were essentially zero. A larger team weight is not an evidence-backed next step by itself.

Diagnose role interactions and the cost of changing previously useful preferences. Predefine one mechanism change after examining these results; possible questions include whether a small joint-action representation or a retention rule addresses the missed interaction. Compare against the original and the selected fixed policy, preserve frozen checkpoints, and budget the extra state/sample cost. These are hypotheses, not promised solutions or changes already installed.

## Later milestones

- Validate scout-delivered learning and interception as gameplay and as measured information-flow mechanisms.
- Add authored situations where tactic choice matters, then separately evaluate new controllers and maps. Three authored layouts are not a map-population benchmark.
- Verify Windows/Linux/mobile targets and genuine external game integration before advertising support there.
- Consider Unity, Godot or Unreal adapters only after the portable API and external demand justify them. They remain deferred.
- Improve public demonstrations using actual recorded examples with aggregate evidence beside them; never imply that a selected successful run is typical.

For each iteration: define a hypothesis and success criterion, freeze the protocol, change one mechanism, retain all outcomes, verify provenance, play it, and record the decision in [research status](research-status.md).
