# Tactical Air microsite

The buildless site source lives in `src/`. The repository builder copies the verified game, evidence, notes, standalone example and release downloads into `dist/`.

From the repository root, after building the game, packaging and validating the release:

```sh
node scripts/build-microsite.mjs
python3 -m http.server 5175 --bind 127.0.0.1 --directory apps/microsite/dist
```

The source bundle deliberately excludes the hosted site identity and Git metadata. A local build creates a static-only hosting manifest if none exists. Register a separate site when publishing your own copy. Never reuse another owner's project identity or credential. The main project has no public Git remote; source is distributed as a checksum-verified download.
