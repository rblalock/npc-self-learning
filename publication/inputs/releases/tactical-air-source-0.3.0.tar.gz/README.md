# Tactical Air

Experimental release 0.3.0: a portable Rust library for enemies that learn which **authored, legal tactics** work, plus a playable browser arena that makes the learning visible.

The game owns perception, movement, combat and rewards. The library owns bounded preference updates, deterministic choice, and memory. It never changes health, damage, movement speed, cooldowns or available abilities.

## Run the prototype

Prerequisites: Rust with Cargo, Node.js 22.12+ (24 recommended), and npm. Install the Wasm target and matching binding generator once:

```sh
rustup target add wasm32-unknown-unknown
cargo install wasm-bindgen-cli --version 0.2.129 --locked
npm ci
npm run dev
```

Open **http://localhost:5173**. The build generates real Rust WebAssembly; there is no JavaScript replacement policy. `npm run dev:ui` skips rebuilding unchanged Rust. `npm run build` creates a static application in `apps/arena/dist`, with relative asset paths.

- **Missions:** the game opens at a two-wave mission. Survive contact, decide whether to intercept the scout, then face reinforcements using its delivered evidence. Win to start the next mission; lose to retry from wave one. Enemy memory carries through both transitions. Mission memory lasts in this tab until reload or switching to Experiments.
- **Play yourself / Watch demo:** top controls switch between manual play and the demo. WASD/arrows move, mouse aims, hold click fires, Space dashes, P pauses. The demo movement selector explicitly offers Circle clockwise, Circle counterclockwise, and Use cover + dodge. These control the demo player, not enemy tactics.
- **Intelligence notes:** Memory shows tactic odds and observations; Last round shows actual learning changes with expandable evidence. The survival graph stays visible in both views.
- **Experiments → Change your movement:** repeat your own movement for four rounds, inspect the evidence, then try a different route, direction, or cover for three rounds. Demo mode explicitly changes its circling direction; manual keys never reverse. Uses fresh memory and preserves free-play saves.
- **Experiments → Field playtest:** two warm-ups, two concealed 12-round conditions (learning vs selected fixed tactics), a movement-change stage, structured questions, source fingerprints, recovery and local export. See [the human protocol](docs/playtest.md).
- **Experiments → Compare enemy learning (legacy):** two three-round manual sets, randomized conditions, notes and local JSON export. Intel is revealed after both sets.
- **Experiments → Require scout reports:** intercept the violet scout before it reaches the relay to stop new information reaching the next squad.
- **Experiments → Random tactics (no learning):** enemies sample their legal tactics uniformly. Stored preferences remain intact and these rounds do not train.
- **New round:** discards unfinished evidence. Completed practice rounds save policy memory locally in the browser, independently of missions.
- **Experiments → Reset memory:** starts a new independent memory with equally likely tactics.

Switching between Missions and Experiments preserves your control mode. Experiments opens paused so you can choose a test or start free practice. Held movement and fire inputs clear when a round ends, a new round starts, the control mode changes, play pauses, or focus leaves the arena.

The manual game currently needs a keyboard and pointer. Touch and narrow-screen visits open in Watch demo, with a visible keyboard-and-mouse requirement for manual play.

## Repository boundaries

```text
crates/tactical-air-core    Pure Rust policy, validation, deterministic RNG, snapshots
crates/tactical-air-wasm    Small wasm-bindgen wrapper over that same core
crates/tactical-air-ffi     Native shared/static library, opaque C ABI and C header
apps/arena                 TypeScript combat simulation, study flow, Canvas renderer, UI
packages/browser           Small typed client over the same Wasm API
scripts                    Wasm build, real-arena evaluation and native C smoke test
```

The core accepts arbitrary host-defined roles, contexts and actions. The arena happens to use three roles with two tactics each: vanguard (close distance / hold lane), flanker (left / right), and ranger (aim / lead movement). The arena uses one context initially to keep its behavior inspectable; the library supports multiple contexts.

At an encounter boundary:

1. The host supplies a role, context and legal action mask.
2. The library samples a tactic and returns a decision ID.
3. The game executes that tactic using its ordinary combat rules.
4. The host reports observed reward against the decision ID.
5. A commit aggregates evidence, applies bounded updates, and enables a versioned save.

Selection is a contextual bandit with exploration, not a neural network or an LLM. It learns rewards supplied by the host; it does not independently know what is fun or fair. The host must enforce truthful observations and useful attribution. The browser enemy host tracks last-seen positions and uses line of sight; the core itself cannot verify world geometry.

See [learning rules and limitations](docs/learning.md), [JSON contract](docs/contract.md), and [Rust, browser, C#, and C++ integration](docs/integration.md).

## Download and integrate

See the [release quick start](docs/releases/quickstart.md) for the browser kit, npm tarball, Rust source and macOS arm64 C ABI bundle. All are MIT-licensed experimental downloads. They are not published to npm or crates.io. Check `SHA256SUMS` beside the downloads.

The independent guard examples use a different vocabulary and no arena code: `cargo run --locked --release -p tactical-air-core --example guard_host`, or serve the extracted browser kit over HTTP. Their synthetic rewards demonstrate the API, not combat effectiveness. Unity, Godot and Unreal adapters remain deferred.

## Verification and evidence

```sh
npm test                     # Rust, Wasm, typed SDK, actual combat and study tests
npm run test:ffi              # Real C caller on macOS/Linux
npm run test:experiments      # Experiment adapter and scenario invariants
npm run build                # Typed, fingerprinted production arena + playtest
npm run verify:evidence      # Historical archive and both new experiment verifiers
```

The original v1 experiment sources and generated binaries are immutable in `docs/experiments/baseline-v1.source.tar.gz`. `node scripts/evidence-baseline.mjs` checks its checksum, extracts it under `target/evidence-baseline-v1`, and verifies the historical reward evidence. Historical experiment commands run inside that archive, rather than against the evolved application.

New runners reuse that simulator and learner. They verify sources, preserve every seed and round, and refuse to overwrite evidence:

```sh
node scripts/evaluate-additive.mjs --out docs/experiments/additive-credit-v1-replication
node scripts/verify-additive.mjs docs/experiments/additive-credit-v1-replication.results.json
node scripts/evaluate-scenarios.mjs --out docs/experiments/scenario-transfer-v1-replication
node scripts/verify-scenarios.mjs docs/experiments/scenario-transfer-v1-replication.results.json
```

The [research record](docs/research-status.md) includes positive and negative results. Continued learning helps after reversal in tested cases, fails against feints on the original map, and offers no damage benefit in the original cover fixture. Both team-credit candidates failed their advancement criteria, so **the game retains its original reward**. Three separately specified cover/spawn scenarios add evidence of environment dependence; they do not establish arbitrary-map or human effectiveness.

The [guided playtest](docs/playtest.md) measures a different question: can people recognize, exploit and enjoy adaptation? It is implemented and automated QA passes in both condition orders. No controlled human dataset has been collected. QA exports are explicitly excluded by `scripts/analyze-playtests.mjs`.

See [release notes](docs/releases/CHANGELOG.md), [timing data](docs/releases/performance-0.3.0.json), [verification](docs/verification-0.3.md), and the [roadmap](docs/roadmap.md). Timing uses a small synthetic policy on one Mac, not the arena or a production capacity test.

## Where this goes next

Collect 6–10 formative human sessions, retain partial sessions, and compare unaided descriptions, counterplay, enjoyment, fairness and frustration. Then choose the next mechanism experiment from the evidence. The player-facing aim is: “They figured out what I was doing—and I figured out how to use that against them.” That remains a design aim, not an established human finding.

The two-wave mission loop repeats the same battlefield and roster. Learning can make familiar habits more dangerous; mission numbers do not increase stats or guarantee a harder encounter. More worlds, scout-report effectiveness studies and engine integrations are later work.

## Relationship to Ink and visual references

This is inspired by the separation of learned choices and fixed constraints discussed in [Ink's adaptive learning](https://github.com/siliconjungle/ink-lang/blob/main/docs/adaptive-learning.md) and [policy learning](https://github.com/siliconjungle/ink-lang/blob/main/docs/policy-learning.md). It is an independent Rust implementation, **not an Ink runtime, compiler integration, or formal proof system**.

The illustrated field map uses an original AI-generated watercolor terrain plate with authored Canvas fortifications and unit counters. [Asset provenance](docs/assets/README.md) records the prompt and font licenses. The first geometric arena built on our original diagram. [Factory](https://github.com/Khalidabdi1/factory) informed the fine-line technical presentation; [Hollowflux](https://developers.openai.com/showcase/hollowflux) informed the emphasis on readable combat. No assets or game source were copied from either project.
