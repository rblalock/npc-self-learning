# Tactical Air: validated adaptation opportunities

MIT-licensed Node.js 24 research kit. No npm install, API key or Rust rebuild.

Read [the guide](docs/opportunity-lab-v2.md) and [verification](docs/verification-opportunity-v2.md). Open docs/experiments/opportunity-validation-v2-view-2.html for offline playback.

Run `shasum -a 256 -c SHA256SUMS`, `npm test`, then `npm run verify:opportunity-v2`. Reproduce to a new output prefix as explained in the guide; evidence writers refuse overwrites.

All 46,080 reserved fights and 4,608 development fights are retained, including rejected candidates. Five primary screens pass in this deliberately selected challenge population; joint squad remains inconclusive. No production learner was changed.
