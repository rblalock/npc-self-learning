Tactical Air: minimum-exposure NPC switching study, v3

Node.js 24, Python 3 and system tar. No package install or model account required.
shasum -a 256 -c SHA256SUMS
npm run verify
python3 scripts/analyze-agentic-v3.py results.json summary.json
node scripts/replay-agentic-v3.mjs results.json regenerated-view.html

Open view.html to inspect actual fights, proposals and applied plans.
The three-observation rule is an execution constraint, not a statistical test.
Both active arms retain full planner history/notes and ordinary Rust learning.
Two familiar worlds and reused schedules are development evidence only.
Replay uses recorded decisions; new model sampling may differ.
