Incomplete NPC agent follow-up: attempt 1

The Claude CLI was signed out. Four in-flight initialization requests failed
before inference (zero reported input/output tokens and zero reported cost).
The latched failure stop prevented further requests. This is not a completed
agent comparison and provides no agent-effectiveness result.

Requires Node.js 24. No dependencies, account or model calls needed.
Check archive contents: shasum -a 256 -c SHA256SUMS
Replay the 1,700 preserved physical fights: npm run verify

The sources and protocol are frozen as used for this attempt. A later run must
use a new output directory, preserve this attempt, and disclose the restart.
