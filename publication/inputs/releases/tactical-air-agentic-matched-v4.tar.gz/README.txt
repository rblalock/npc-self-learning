Tactical Air: matched-experience NPC plan selection, v4

Node.js 24, Python 3 and system tar. No package install or model account required.
shasum -a 256 -c SHA256SUMS
npm run verify
python3 scripts/analyze-agentic-v4.py results.json summary.json
node scripts/replay-agentic-v4-r2.mjs results.json regenerated-view.html

view.html uses presentation revision 2 (mobile wrapping and request-count wording).
The original viewer is view-original.html; all 51 frozen study sources remain unchanged.
Both viewer generators and templates are included and checksummed.

Open view.html for the shared preparation, all evaluation trajectories and first/final fight recordings.
Both selectors receive the same initial evidence and menu, then their own completed histories.
Ordinary Rust learning continues. Prior fixed calibration is an extra-experience diagnostic.
These familiar worlds and reused schedules are development evidence only.
Replay uses recorded model outputs; a new model run may differ.
