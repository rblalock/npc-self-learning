# Tactical Air: conservative interventions

MIT-licensed Node.js 24 research kit. No npm install, API key or Rust rebuild. Python 3 is optional for the separate arithmetic check.

Read [the guide](docs/conservative-intervention-v1.md). Open docs/experiments/conservative-development-v1-view.html for offline playback.

Run `shasum -a 256 -c SHA256SUMS`, `npm test`, `npm run verify`, and `python3 scripts/check-conservative-arithmetic-v1.py`. Regenerate with a new output prefix as explained in the guide. Writers refuse overwrites.

This is development on 48 previously examined cases: 259,584 cached transitions, zero new scored physical fights. All candidates fail their advancement gates. The original learner remains unchanged. Verification repeats 192 table fights and 8,160 trajectory fights; those are not new inferential samples. The kit includes source audit and selection records, the archived Rust/Wasm runtime, every transition, aggregate results, checksums, and 126 reconstructed recordings.
