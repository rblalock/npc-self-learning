Tactical Air: agent-assisted NPC development pilot

Requires Node.js 24 and tar. No dependency install or model credentials.
Verify archive contents: shasum -a 256 -c SHA256SUMS
Re-execute all combat/policy decisions: npm run verify
Open view.html to inspect the recorded fights and every agent adjustment.

This kit freezes the sources actually used for the run. It replays recorded
model outputs; it does not claim that new model requests reproduce them.
Two familiar cases are development evidence, not fresh validation.
