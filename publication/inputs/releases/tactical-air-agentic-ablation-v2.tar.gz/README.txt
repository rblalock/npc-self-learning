Tactical Air: repeated NPC review and planner-history development study

Requires Node.js 24 and tar. No dependency install or model credentials.
Verify archive contents: shasum -a 256 -c SHA256SUMS
Re-execute all combat/policy decisions: npm run verify
Check descriptive arithmetic (Python 3): python3 scripts/analyze-agentic-v2.py results.json summary.json
Regenerate the viewer: node scripts/replay-agentic-v2.mjs results.json regenerated-view.html
Open view.html to inspect the recorded fights and every agent adjustment.

This kit freezes the sources actually used for the run. It replays recorded
model outputs; it does not claim that new model requests reproduce them.
Two familiar cases are development evidence, not fresh validation.
