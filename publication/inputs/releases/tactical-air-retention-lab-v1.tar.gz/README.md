# Tactical Air retention lab

MIT-licensed headless research kit. Requires Node.js 24; no npm install, API key or Rust rebuild.

Read [the guide](docs/retention-lab.md). Open docs/experiments/retention-v1-view.html for the preselected four-condition replay.

Check files with `shasum -a 256 -c SHA256SUMS`, then `npm test`. See the guide for reproduction commands. Result and verification writers refuse to overwrite evidence: reproduce to a new target prefix before invoking a verifier.

This includes 17,856 new measured encounters across two follow-ups, plus the prior population data needed to reconstruct switch checkpoints. The original learner remains unchanged; unfavorable findings are retained.
